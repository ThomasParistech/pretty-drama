# PrettyDrama — icône de titre

Deux fichiers, dessin identique à la référence fournie (tracés non modifiés : seuls le fond
carré et les couleurs ont changé). Optimisés : 9,4 ko -> ~3,5 ko chacun.

- `icons/drama-wine.svg` — variante **5A** : masques en vin (#8C2338), intérieur crème (#FAF3EC).
  Pour un usage sans jeton, directement sur le fond crème de la page.
- `icons/drama-token.svg` — variante **5D** : le même dessin posé dans le jeton sable (#F6E7DC).
  Remplacement direct de l'icône actuelle du header, même encombrement.

## Intégration

Remplacer l'icône du lockup `PrettyDrama` dans le header :

```html
<!-- 5A : sans jeton, sur fond crème -->
<span style="display:flex;align-items:center;gap:10px">
  <img src="/icons/drama-wine.svg" alt="" width="30" height="30" />
  <span class="wordmark">PrettyDrama</span>
</span>

<!-- 5D : dans le jeton sable (remplace le rond actuel) -->
<span style="display:flex;align-items:center;gap:10px">
  <img src="/icons/drama-token.svg" alt="" width="34" height="34" />
  <span class="wordmark">PrettyDrama</span>
</span>
```

## Notes d'implémentation

- viewBox `0 0 329 345` (un peu plus haut que large) : contraindre la **hauteur** et laisser la
  largeur libre, ou fixer width/height égaux avec `object-fit: contain` — jamais d'étirement.
- Icône décorative : garder `alt=""`, le mot « PrettyDrama » porte déjà le nom.
- Favicon : utiliser `drama-token.svg`, le jeton plein reste lisible à 16 px.
- Les intérieurs des masques sont des **aplats opaques** (crème / sable), pas de transparence.
  Si le fond de page change, mettre à jour ces valeurs dans le fichier (attributs `fill`).
- Aucune dépendance, aucun `<style>`, aucun id : les fichiers peuvent être inlinés tels quels.

## Couleurs

| Rôle | Hex |
| --- | --- |
| Vin — trait, mot-vedette | `#8C2338` |
| Crème — fond de page, intérieur 5A | `#FAF3EC` |
| Sable — jeton, intérieur 5D | `#F6E7DC` |
